package br.com.etecia.volleyapi_imagem;

public class ContentInfo {
    public Object getClip() {
    }
}
