package br.com.etecia.volleyapi_imagem;

public class ContentInfoCompat {
    public Object getClip() {
    }
}
