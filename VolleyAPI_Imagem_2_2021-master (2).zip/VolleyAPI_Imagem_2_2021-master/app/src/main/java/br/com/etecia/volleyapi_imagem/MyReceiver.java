package br.com.etecia.volleyapi_imagem;

import android.view.View;

public interface MyReceiver {
    ContentInfoCompat onReceiveContent(View view, ContentInfoCompat contentInfo);
}
